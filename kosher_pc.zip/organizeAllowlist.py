# Header content
header = r"""Windows Registry Editor Version 5.00

[HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Google\Chrome\URLAllowlist]

"""

# Read the content of the .reg file
file_to_edit='.\\ops\\URLAllowlist.reg'
with open(file_to_edit, 'r') as file:
    content = file.readlines()

# Remove empty lines and strip whitespace
content = [line.strip() for line in content if line.strip()]

# Create a dictionary to store unique URLs along with their indexes
unique_urls = {}

# Parse the content and populate the dictionary
for line in content:
    if '=' in line:
        parts = line.split('=')
        if len(parts) == 2:
            index = parts[0].strip('"')
            url = parts[1].strip('"')
            if url not in unique_urls.values():
                unique_urls[index] = url

# Sort the unique URLs alphabetically
sorted_urls = sorted(unique_urls.items(), key=lambda x: x[1])

# Prepare the sorted content with corrected indexes starting from 1
sorted_content = [f'"{i}"="{url}"\n' for i, (index, url) in enumerate(sorted_urls, start=1)]

# Write the header and sorted content back to the .reg file
with open(file_to_edit, 'w') as file:
    file.write(header)
    file.writelines(sorted_content)

print("{} is edited succecfuly".format(file_to_edit))